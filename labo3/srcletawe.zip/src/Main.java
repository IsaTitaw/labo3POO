import be.ifosup.*;


public class Main {
    public static void main(String[] args) {
        Vehicule monvehicule = new Vehicule("ma chouette auto");
        System.out.println(monvehicule.getNom());
        System.out.println(monvehicule.Vehicule());
        Voiture mavoiture = new Voiture("Ma chouette auto", "Smart", "For2", "orange", 84);
        System.out.println(mavoiture);
        mavoiture.faisqqchose();
        mavoiture.demarrer();
        mavoiture.roule();
        mavoiture.arreter();

        Batmobile mabatmobile = new Batmobile();
        System.out.println(mabatmobile.faisqqchose());
        mabatmobile.decolle();
        mabatmobile.roulesouseau();
        mabatmobile.arreter();

        Hovercraft monhovercraft = new Hovercraft();
        System.out.println(monhovercraft.Vehicule());
        System.out.println(monhovercraft.faisqqchose());

        Bateau monbateau = new Bateau();
        System.out.println(monbateau.Vehicule());

    }


}
