package be.ifosup;

public interface Amphibie {
    void roulesouseau();
    void roulesurterre();
}
