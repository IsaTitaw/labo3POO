package be.ifosup;

public interface Volant {
    void vole();
    void decolle();
    void atterit();
}
