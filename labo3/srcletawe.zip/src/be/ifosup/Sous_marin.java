package be.ifosup;

public interface Sous_marin {
    void deplacesouseau();
    void remontesurface();
}
