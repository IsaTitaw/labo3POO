package be.ifosup;

public interface Roulant {
    void roule();
    void demarrer();
    void arreter();
}
